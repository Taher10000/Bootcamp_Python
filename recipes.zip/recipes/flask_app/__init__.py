# __init__.py
from flask import Flask, session


app = Flask(__name__)
app.secret_key = "1h3kl32h432u92h4i3njkq"
